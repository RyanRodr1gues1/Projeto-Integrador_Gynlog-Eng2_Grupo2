package controle;

import java.util.ArrayList;
import modelos.classes.TipoDeMovimentacao;
import modelos.interfaces.ITipoDeMovimentacaoCRUD;
import persistencia.TipoDeMovimentacaoDAO;



public class MovimentacaoControle implements ITipoDeMovimentacaoCRUD {

    private TipoDeMovimentacaoDAO dao;

    public MovimentacaoControle() {
        dao = new TipoDeMovimentacaoDAO();
    }

    @Override
    public void salvar(TipoDeMovimentacao tipoDeMovimentacao) throws Exception {
        
        if (tipoDeMovimentacao.getIdMovimentacao() <= 0 ) {
            throw new Exception("O ID deve ser maior que zero!");
        }

        TipoDeMovimentacao existente = dao.buscarPorId(tipoDeMovimentacao.getIdMovimentacao());
        if (existente != null) {
            throw new Exception("Esse ID já existe! Escolha outro.");
        }
        if (tipoDeMovimentacao.getIdVeiculo() == null || tipoDeMovimentacao.getIdVeiculo().trim().isEmpty()) {
            throw new Exception("Selecione um veículo!");
        }

        if (tipoDeMovimentacao.getIdTipoDespesa() == null || tipoDeMovimentacao.getIdTipoDespesa().trim().isEmpty()) {
            throw new Exception("Selecione um tipo de despesa!");
        }


        if (tipoDeMovimentacao.getValor() <= 0) {
            throw new Exception("O valor deve ser maior que zero!");
        }

        dao.salvar(tipoDeMovimentacao);

    }

    @Override
    public ArrayList<TipoDeMovimentacao> listaDeTiposDeMovimentacao() throws Exception {
        return dao.listaDeTiposDeMovimentacao();
    }

    @Override
    public TipoDeMovimentacao buscarPorId(int idMovimentacao) throws Exception {
        return dao.buscarPorId(idMovimentacao);
    }

    @Override
    public void atualizar(TipoDeMovimentacao tipoDeMovimentacao) throws Exception {
        if (tipoDeMovimentacao.getIdMovimentacao() <= 0 ) {
            throw new Exception("O ID deve ser maior que zero!");
        }
        
        if (tipoDeMovimentacao.getIdVeiculo() == null || tipoDeMovimentacao.getIdVeiculo().trim().isEmpty()) {
            throw new Exception("Selecione um veículo!");
        }

        if (tipoDeMovimentacao.getIdTipoDespesa() == null || tipoDeMovimentacao.getIdTipoDespesa().trim().isEmpty()) {
            throw new Exception("Selecione um tipo de despesa!");
        }

        if (tipoDeMovimentacao.getValor() <= 0) {
            throw new Exception("O valor deve ser maior que zero!");
        }
        TipoDeMovimentacao original = dao.buscarPorId(tipoDeMovimentacao.getIdMovimentacao());
        if (original == null) {
            throw new Exception("Essa movimentação não existe mais no banco!");
        }

        if (tipoDeMovimentacao.getIdMovimentacao() != original.getIdMovimentacao()) {
            throw new Exception("Não é permitido alterar o id!");
        }

        dao.atualizar(tipoDeMovimentacao);
    }

    @Override
    public void remover(int idMovimentacao) throws Exception {
        if (idMovimentacao <= 0) {
            throw new Exception("ID inválido para remoção!");
        }
        TipoDeMovimentacao tipoDeMovimentacao = dao.buscarPorId(idMovimentacao);

        dao.remover(idMovimentacao);

    }

}