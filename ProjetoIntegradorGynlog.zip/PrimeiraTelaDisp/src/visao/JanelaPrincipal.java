
package visao;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;

public class JanelaPrincipal extends javax.swing.JFrame {

    public JanelaPrincipal() {
        initComponents();
        
        estilizarBotao();
        setLocationRelativeTo(null);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new GradientPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new RoundedPanel();
        jButtonVeiculos = new javax.swing.JButton();
        jButtonDispesas = new javax.swing.JButton();
        jButtonRelatorio = new javax.swing.JButton();
        jButtonMovimentacao = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));

        jLabel1.setFont(new java.awt.Font("Arial", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("GYN");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logooo_batcheditor_fotor.png"))); // NOI18N

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setForeground(new java.awt.Color(255, 255, 255));

        jButtonVeiculos.setBackground(new java.awt.Color(0, 153, 153));
        jButtonVeiculos.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButtonVeiculos.setForeground(new java.awt.Color(255, 255, 255));
        jButtonVeiculos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/carr.png"))); // NOI18N
        jButtonVeiculos.setText(" CADASTRO DE VEÍCULOS");
        jButtonVeiculos.setBorder(null);
        jButtonVeiculos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonVeiculosActionPerformed(evt);
            }
        });

        jButtonDispesas.setBackground(new java.awt.Color(0, 153, 153));
        jButtonDispesas.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButtonDispesas.setForeground(new java.awt.Color(255, 255, 255));
        jButtonDispesas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/din.png"))); // NOI18N
        jButtonDispesas.setText("CADASTRO DE DESPESAS");
        jButtonDispesas.setBorder(null);
        jButtonDispesas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDispesasActionPerformed(evt);
            }
        });

        jButtonRelatorio.setBackground(new java.awt.Color(0, 153, 153));
        jButtonRelatorio.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButtonRelatorio.setForeground(new java.awt.Color(255, 255, 255));
        jButtonRelatorio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/rela.png"))); // NOI18N
        jButtonRelatorio.setText("                       RELATÓRIOS");
        jButtonRelatorio.setBorder(null);
        jButtonRelatorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRelatorioActionPerformed(evt);
            }
        });

        jButtonMovimentacao.setBackground(new java.awt.Color(0, 153, 153));
        jButtonMovimentacao.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButtonMovimentacao.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMovimentacao.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/set.png"))); // NOI18N
        jButtonMovimentacao.setText("                MOVIMENTAÇÃO");
        jButtonMovimentacao.setBorder(null);
        jButtonMovimentacao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMovimentacaoActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 153));
        jLabel3.setText("SELECIONE UMA OPÇÃO:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonVeiculos, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonDispesas, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonMovimentacao, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButtonVeiculos, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jButtonDispesas, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jButtonMovimentacao, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        jLabel4.setFont(new java.awt.Font("Arial", 3, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("LOG");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(159, 159, 159)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 163, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(146, 146, 146)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel4))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(56, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void estilizarBotao(){
  final int raio = 25; // <-- ARREDONDAMENTO DO BOTÃO

    // ====== CORES DO DEGRADÊ NORMAL ======
    final Color corIni    = new Color(0, 180, 190);
    final Color corFim    = new Color(0, 130, 140);

    // ====== CORES DO DEGRADÊ HOVER / ILUMINADO ======
    final Color corHoverIni = new Color(0, 220, 230);
    final Color corHoverFim = new Color(0, 170, 180);

    // ====== CORES DO DEGRADÊ CLICK ======
    final Color corClickIni = new Color(0, 150, 160);
    final Color corClickFim = new Color(0, 110, 120);

    JButton[] botoes = {
        jButtonVeiculos,
        jButtonRelatorio,
        jButtonDispesas,
        jButtonMovimentacao
    };

    for (JButton btn : botoes) {

        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 16));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);

        // Truque p/ hover funcionar sem erro de "final"
        final Color[] ini = { corIni };
        final Color[] fim = { corFim };

        // DESENHO COMPLETO DO BOTÃO
        btn.setUI(new javax.swing.plaf.basic.BasicButtonUI() {

            @Override
            public void paint(Graphics g, JComponent c) {

                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);

                // fundo do degradê
                GradientPaint grad = new GradientPaint(
                    0, 0, ini[0],
                    0, btn.getHeight(), fim[0]
                );

                g2.setPaint(grad);
                g2.fillRoundRect(0, 0, btn.getWidth(), btn.getHeight(), raio, raio);

                g2.dispose();
                super.paint(g, c);
            }

            // SEM ISSO o Swing recorta o botão quadrado!
            @Override
            public void installUI(JComponent c) {
                super.installUI(c);
                c.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
            }

            public Shape getShape(JComponent c) {
                return new java.awt.geom.RoundRectangle2D.Float(
                    0, 0, c.getWidth(), c.getHeight(), raio, raio
                );
            }
        });

        // HOVER / CLICK
        btn.addMouseListener(new java.awt.event.MouseAdapter() {

            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ini[0] = corHoverIni;
                fim[0] = corHoverFim;
                btn.repaint();
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ini[0] = corIni;
                fim[0] = corFim;
                btn.repaint();
            }

            @Override
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ini[0] = corClickIni;
                fim[0] = corClickFim;
                btn.repaint();
            }

            @Override
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                ini[0] = corHoverIni;
                fim[0] = corHoverFim;
                btn.repaint();
            }
        });
    }
        
    }

    private void jButtonVeiculosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonVeiculosActionPerformed
        // TODO add your handling code here:
        TelaCadrastroVeiculos tela = null;
        try {
            tela = new TelaCadrastroVeiculos();
        } catch (Exception ex) {
            Logger.getLogger(JanelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        tela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButtonVeiculosActionPerformed

    private void jButtonDispesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDispesasActionPerformed
        // TODO add your handling code here:
        TelaDispesa tela = new TelaDispesa();
        tela.setVisible(true);
        this.dispose();


    }//GEN-LAST:event_jButtonDispesasActionPerformed

    private void jButtonMovimentacaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMovimentacaoActionPerformed
        // TODO add your handling code here:
        TelaMovimentacao tela = new TelaMovimentacao();
        tela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButtonMovimentacaoActionPerformed

    private void jButtonRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRelatorioActionPerformed
        // TODO add your handling code here:
        TelaRelatorios tela = new TelaRelatorios();
        tela.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_jButtonRelatorioActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JanelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JanelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JanelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JanelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JanelaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonDispesas;
    private javax.swing.JButton jButtonMovimentacao;
    private javax.swing.JButton jButtonRelatorio;
    private javax.swing.JButton jButtonVeiculos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
