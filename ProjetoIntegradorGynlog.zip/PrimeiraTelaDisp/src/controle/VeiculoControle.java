
package controle;

import java.util.ArrayList;
import modelos.classes.Veiculos;
import persistencia.VeiculosDAO;
import modelos.interfaces.IVeiculosCRUD;

public class VeiculoControle implements IVeiculosCRUD {

    private VeiculosDAO dao;

    public VeiculoControle() throws Exception {
        dao = new VeiculosDAO();
    }

    @Override
    public void salvar(Veiculos veiculo) throws Exception {
        if (veiculo.getIdVeiculo() <= 0 ) {
            throw new Exception("O ID deve ser maior que zero!");
        }

        Veiculos existeID = dao.buscarPorId(veiculo.getIdVeiculo());
        if (existeID != null) {
            throw new Exception("O ID já existe, digite outro!");
        }

        Veiculos existePlaca = dao.buscarPorPlaca(veiculo.getPlaca());
        if (existePlaca != null) {
            throw new Exception("A placa já existe, digite outra!");
        }
        dao.salvar(veiculo);
    }

    @Override
    public ArrayList<Veiculos> listaDeVeiculos() throws Exception {
        return dao.listaDeVeiculos();
    }

    @Override
    public Veiculos buscarPorId(int idVeiculo) throws Exception {
        return dao.buscarPorId(idVeiculo);
    }

    @Override
    public void atualizar(Veiculos veiculo) throws Exception {
        
        if (veiculo.getIdVeiculo() <= 0 ) {
            throw new Exception("O ID deve ser maior que zero!");
        }

        Veiculos original = dao.buscarPorId(veiculo.getIdVeiculo());
        if (original == null) {
            throw new Exception("Veículo não encontrado!");
        }

        if (veiculo.getIdVeiculo() != original.getIdVeiculo()) {
            throw new Exception("Não é permitido mudar o ID!");
        }

        Veiculos existePlaca = dao.buscarPorPlaca(veiculo.getPlaca());
        if (existePlaca != null && existePlaca.getIdVeiculo() != veiculo.getIdVeiculo()) {
            throw new Exception("Essa placa já pertence a outro veículo!");
        }
        dao.atualizar(veiculo);
    }

    @Override
    public void remover(int idVeiculo) throws Exception {
        Veiculos veiculo = dao.buscarPorId(idVeiculo);
        dao.remover(idVeiculo);
    }

    @Override
    public Veiculos buscarPorPlaca(String placa) throws Exception {
        return dao.buscarPorPlaca(placa);
    }
}
