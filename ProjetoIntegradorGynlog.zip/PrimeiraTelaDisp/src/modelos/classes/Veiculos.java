
package modelos.classes;
import modelos.classes.StatusVeiculo;

public class Veiculos {
    //Atributos:
    
    private int idVeiculo  = 0;
    private String placa = "";
    private String modelo = "";
    private int anoFabricacao = 0;
    private StatusVeiculo status;
    
       //Métodos:
    public Veiculos(){
    //Construtor
    }
    
    public Veiculos(int idVeiculo,String placa,String modelo,int anoFabricacao, StatusVeiculo status){
        //Construtor com parametro:
    this.idVeiculo = idVeiculo;
    this.placa = placa;
    this.modelo = modelo;
    this.anoFabricacao = anoFabricacao;
    this.status = status;
          
 }
    
    public int getIdVeiculo() {
        return idVeiculo;
    }

    public void setIdVeiculo(int idVeiculo) {
        this.idVeiculo = idVeiculo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAnoFabricacao() {
        return anoFabricacao;
    }

    public void setAnoFabricacao(int anoFabricacao) {
        this.anoFabricacao = anoFabricacao;
    }

    public StatusVeiculo getStatus() {
        return status;
    }

    public void setStatus(StatusVeiculo status) {
        this.status = status;
    }
   
    
}

    