package visao;

import java.util.ArrayList;
import modelos.classes.*;
import persistencia.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import controle.*;
import java.awt.Color;

public class TelaMovimentacao extends javax.swing.JFrame {

    public TelaMovimentacao() {
        initComponents();
        setLocationRelativeTo(null);
        carregarTabela();
        limparCampos();

        controle = new MovimentacaoControle();
        carregarComboTipoDespesa();
        carregarComboVeiculos();
        jTextFieldIdMovimentacao.setEditable(true);
    }
    MovimentacaoControle controle = null;

    private void carregarComboVeiculos() {
        try {
            jComboBoxVeiculo.removeAllItems(); // limpa antes
            VeiculosDAO dao = new VeiculosDAO();
            ArrayList<Veiculos> lista = dao.listaDeVeiculos(); // pega as despesas cadastradas

            for (Veiculos tipo : lista) {
                if(tipo.getStatus()== StatusVeiculo.Ativo){
                // adiciona apenas o ID no comboBox
                jComboBoxVeiculo.addItem(String.valueOf(tipo.getIdVeiculo() + " - " + tipo.getModelo()));
            }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar Tipo de Despesa: " + e.getMessage());
        }
    }

    private void carregarComboTipoDespesa() {
        try {
            jComboBoxTipoDespesa.removeAllItems(); // limpa antes
            TipoDeDespesasDAO dao = new TipoDeDespesasDAO();
            ArrayList<TipoDeDespesa> lista = dao.listaDeTiposDeDespesas();; // pega as despesas cadastradas

            for (TipoDeDespesa tipo : lista) {
                // adiciona apenas o ID no comboBox
                jComboBoxTipoDespesa.addItem(String.valueOf(tipo.getIdTipoDeDespesa() + " - " + tipo.getDescricao()));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar Tipo de Despesa: " + e.getMessage());
        }
    }

    private void carregarTabela() {
        try {
            TipoDeMovimentacaoDAO dao = new TipoDeMovimentacaoDAO();
            ArrayList<TipoDeMovimentacao> lista = dao.listaDeTiposDeMovimentacao();

            DefaultTableModel modelo = (DefaultTableModel) jTableResultado.getModel();
            modelo.setRowCount(0);

            for (TipoDeMovimentacao obj : lista) {

                // Formatar o valor para aparecer como 1.234,56
                String valorFormatado = String.format("%,.2f", obj.getValor())
                        .replace(".", "#")
                        .replace(".", ",")
                        .replace("#", ".");

                modelo.addRow(new Object[]{
                    obj.getIdMovimentacao(),
                    obj.getIdVeiculo(),
                    obj.getIdTipoDespesa(),
                    obj.getData(),
                    valorFormatado,
                    obj.getDescricao()
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar tabela: " + e.getMessage());
        }
    }

    private void limparCampos() {
        jTextFieldIdMovimentacao.setText("");
        jComboBoxVeiculo.setSelectedIndex(-1);
        jComboBoxTipoDespesa.setSelectedIndex(-1);
        jTextFieldDescricao.setText("");
        jFormattedTextFieldData.setText("");
        jFormattedTextFieldValor.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSpinner1 = new javax.swing.JSpinner();
        jPanel1 = new GradientPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel3 = new RoundedPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextFieldIdMovimentacao = new javax.swing.JTextField();
        jComboBoxVeiculo = new javax.swing.JComboBox<>();
        jComboBoxTipoDespesa = new javax.swing.JComboBox<>();
        jTextFieldDescricao = new javax.swing.JTextField();
        jFormattedTextFieldData = new javax.swing.JFormattedTextField();
        jFormattedTextFieldValor = new javax.swing.JFormattedTextField();
        jButtonRemover = new javax.swing.JButton();
        jButtonAtualizar = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableResultado = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        jLabel7.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/set.png"))); // NOI18N
        jLabel7.setText("Movimentação");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("ID MOVIMENTAÇÃO:");

        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("ID VEÍCULO:");

        jLabel3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("ID DESPESAS:");

        jLabel4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("DESCRIÇÃO:");

        jLabel5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("DATA:");

        jLabel6.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("VALOR:");

        jTextFieldIdMovimentacao.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldIdMovimentacao.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextFieldIdMovimentacao.setForeground(new java.awt.Color(0, 0, 0));
        jTextFieldIdMovimentacao.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 3));

        jComboBoxVeiculo.setBackground(new java.awt.Color(255, 255, 255));
        jComboBoxVeiculo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jComboBoxVeiculo.setForeground(new java.awt.Color(0, 0, 0));
        jComboBoxVeiculo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxVeiculo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 3));
        jComboBoxVeiculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxVeiculoActionPerformed(evt);
            }
        });

        jComboBoxTipoDespesa.setBackground(new java.awt.Color(255, 255, 255));
        jComboBoxTipoDespesa.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jComboBoxTipoDespesa.setForeground(new java.awt.Color(0, 0, 0));
        jComboBoxTipoDespesa.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxTipoDespesa.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 3));
        jComboBoxTipoDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoDespesaActionPerformed(evt);
            }
        });

        jTextFieldDescricao.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldDescricao.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextFieldDescricao.setForeground(new java.awt.Color(0, 0, 0));
        jTextFieldDescricao.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 3));

        jFormattedTextFieldData.setBackground(new java.awt.Color(255, 255, 255));
        jFormattedTextFieldData.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 3));
        jFormattedTextFieldData.setForeground(new java.awt.Color(0, 0, 0));
        try {
            jFormattedTextFieldData.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jFormattedTextFieldValor.setBackground(new java.awt.Color(255, 255, 255));
        jFormattedTextFieldValor.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 3));
        jFormattedTextFieldValor.setForeground(new java.awt.Color(0, 0, 0));
        jFormattedTextFieldValor.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0.00"))));
        jFormattedTextFieldValor.setPreferredSize(new java.awt.Dimension(150, 22));
        jFormattedTextFieldValor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFormattedTextFieldValorActionPerformed(evt);
            }
        });

        jButtonRemover.setBackground(new java.awt.Color(0, 102, 102));
        jButtonRemover.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButtonRemover.setForeground(new java.awt.Color(255, 255, 255));
        jButtonRemover.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/li.png"))); // NOI18N
        jButtonRemover.setText("  EXCLUIR");
        jButtonRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemoverActionPerformed(evt);
            }
        });

        jButtonAtualizar.setBackground(new java.awt.Color(0, 102, 102));
        jButtonAtualizar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButtonAtualizar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonAtualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/ediatrCerto.png"))); // NOI18N
        jButtonAtualizar.setText("  EDITAR");
        jButtonAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAtualizarActionPerformed(evt);
            }
        });

        jButtonSalvar.setBackground(new java.awt.Color(0, 102, 102));
        jButtonSalvar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButtonSalvar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/incluir.png"))); // NOI18N
        jButtonSalvar.setText("INCLUIR");
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel3)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldIdMovimentacao, javax.swing.GroupLayout.DEFAULT_SIZE, 233, Short.MAX_VALUE)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jComboBoxTipoDespesa, javax.swing.GroupLayout.Alignment.LEADING, 0, 233, Short.MAX_VALUE)
                                .addComponent(jTextFieldDescricao, javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jFormattedTextFieldData, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 123, Short.MAX_VALUE)
                                    .addComponent(jFormattedTextFieldValor, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jComboBoxVeiculo, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(130, 130, 130)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonSalvar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonAtualizar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonRemover, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(27, 27, 27))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldIdMovimentacao, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jComboBoxVeiculo, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(30, 30, 30)
                                        .addComponent(jLabel3))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jButtonAtualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jComboBoxTipoDespesa, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4)
                                    .addComponent(jTextFieldDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jFormattedTextFieldData, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jLabel5)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jFormattedTextFieldValor, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButtonRemover, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(58, 58, 58))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jButtonSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jTableResultado.setBackground(new java.awt.Color(255, 255, 255));
        jTableResultado.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID MOVIMENTAÇÃO", "VEÍCULO", "TIPO DESPESAS", "DATA", "VALOR", "DESCRIÇÃO"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableResultado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableResultadoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableResultado);

        jButton1.setBackground(new java.awt.Color(0, 102, 102));
        jButton1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/voltarll.png"))); // NOI18N
        jButton1.setText("VOLTAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(270, 270, 270))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(15, 15, 15))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxVeiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxVeiculoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxVeiculoActionPerformed

    private void jButtonRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemoverActionPerformed
        // TODO add your handling code here:
        try {
            int linha = jTableResultado.getSelectedRow();
            if (linha == -1) {
                JOptionPane.showMessageDialog(this, "Selecione uma linha para remover!");
                return;
            }   
            int id = Integer.parseInt(jTableResultado.getValueAt(linha, 0).toString());
            controle.remover(id);
            JOptionPane.showMessageDialog(this, "Tipo de despesa removido com sucesso!");
            jTextFieldIdMovimentacao.setEditable(true);
            jTextFieldIdMovimentacao.setText("");
            jTextFieldIdMovimentacao.setBackground(new Color(255,255,255));
            jTextFieldIdMovimentacao.setForeground(Color.BLACK);
            carregarTabela();
            limparCampos();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao remover: " + e.getMessage());
        }

    }//GEN-LAST:event_jButtonRemoverActionPerformed

    private void jButtonAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAtualizarActionPerformed

        try {
            String dataEx = jFormattedTextFieldData.getText().trim();
            String valorTextoEx = jFormattedTextFieldValor.getText().trim();
            
            if (dataEx.equals("//") || dataEx.equals("__/__/____") || dataEx.replace("/", "").trim().isEmpty()) {
                throw new Exception("A data não pode estar vazia!");
            }
            if (valorTextoEx.isEmpty() || valorTextoEx.equals(",00")) {
                throw new Exception("O valor não pode estar vazio!");
            }
            
            int linha = jTableResultado.getSelectedRow();
            if (linha == -1) {
                JOptionPane.showMessageDialog(this, "Selecione uma movimentação para editar!");
                return;
            }

            int id = Integer.parseInt(jTableResultado.getValueAt(linha, 0).toString());
            String descricao = jTextFieldDescricao.getText();
            String data = jFormattedTextFieldData.getText();

            // valor vindo da tabela já formatado (1.999,00)
            String valorTexto = jFormattedTextFieldValor.getText().trim();
            valorTexto = valorTexto.replace(".", "").replace(",", ".");
            double valor = Double.parseDouble(valorTexto);

            String idTipoDespesa = jComboBoxTipoDespesa.getSelectedItem().toString();
            String idVeiculo = jComboBoxVeiculo.getSelectedItem().toString();

            TipoDeMovimentacao tipoDeMovimentacao
                    = new TipoDeMovimentacao(id, idVeiculo, idTipoDespesa, descricao, data, valor);

            controle.atualizar(tipoDeMovimentacao);

            JOptionPane.showMessageDialog(this, "Movimentação atualizada!");
            jTextFieldIdMovimentacao.setEditable(true);
            jTextFieldIdMovimentacao.setText("");
            jTextFieldIdMovimentacao.setBackground(new Color(255,255,255));
            jTextFieldIdMovimentacao.setForeground(Color.BLACK);
            carregarTabela();
            limparCampos();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao editar: " + e.getMessage());
        }
    }//GEN-LAST:event_jButtonAtualizarActionPerformed

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
        // TODO add your handling code here:
        try {
           
            String id = jTextFieldIdMovimentacao.getText().trim();
            String data = jFormattedTextFieldData.getText().trim();
            String valorTexto = jFormattedTextFieldValor.getText().trim();
            
            if( id.isEmpty()) throw new Exception("O ID não pode estar vazio");
            if (data.equals("//") || data.equals("__/__/____") || data.replace("/", "").trim().isEmpty()) {
                throw new Exception("A data não pode estar vazia!");
            }
            if (valorTexto.isEmpty() || valorTexto.equals(",00")) {
                throw new Exception("O valor não pode estar vazio!");
            }
            jTextFieldIdMovimentacao.setEditable(true);
            int idMovimentacao = Integer.parseInt(jTextFieldIdMovimentacao.getText());
            String idVeiculo = jComboBoxVeiculo.getSelectedItem().toString();
            String idTipoDespesa = jComboBoxTipoDespesa.getSelectedItem().toString();
            String descricao = jTextFieldDescricao.getText();
           
            valorTexto = valorTexto.replace(".", "").replace(",", ".");
            double valor = Double.parseDouble(valorTexto);
            
            TipoDeMovimentacao tipoDeMovimentacao = new TipoDeMovimentacao(idMovimentacao, idVeiculo, idTipoDespesa, descricao, data, valor);
            controle.salvar(tipoDeMovimentacao);

            JOptionPane.showMessageDialog(this, "Movimentação salva com sucesso!");
            carregarTabela();
            limparCampos();
        } catch (Exception erro) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao Incluir: " + erro.getMessage());
        }

    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jComboBoxTipoDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoDespesaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxTipoDespesaActionPerformed

    private void jFormattedTextFieldValorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTextFieldValorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFormattedTextFieldValorActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        JanelaPrincipal Janela = new JanelaPrincipal();
        Janela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTableResultadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableResultadoMouseClicked
        // TODO add your handling code here:
        int linha = jTableResultado.getSelectedRow();
        if (linha >= 0) {
            jTextFieldIdMovimentacao.setText(jTableResultado.getValueAt(linha, 0).toString());
            jComboBoxVeiculo.setSelectedItem(jTableResultado.getValueAt(linha, 1).toString());
            jComboBoxTipoDespesa.setSelectedItem(jTableResultado.getValueAt(linha, 2).toString());
            jFormattedTextFieldData.setText(jTableResultado.getValueAt(linha, 3).toString());
            String valor = jTableResultado.getValueAt(linha, 4).toString();
            jFormattedTextFieldValor.setText(valor);
            jTextFieldDescricao.setText(jTableResultado.getValueAt(linha, 5).toString());

            jTextFieldIdMovimentacao.setEditable(false);
            jTextFieldIdMovimentacao.setBackground(Color.LIGHT_GRAY);
            jTextFieldIdMovimentacao.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_jTableResultadoMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaMovimentacao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaMovimentacao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaMovimentacao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaMovimentacao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaMovimentacao().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonAtualizar;
    private javax.swing.JButton jButtonRemover;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JComboBox<String> jComboBoxTipoDespesa;
    private javax.swing.JComboBox<String> jComboBoxVeiculo;
    private javax.swing.JFormattedTextField jFormattedTextFieldData;
    private javax.swing.JFormattedTextField jFormattedTextFieldValor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JTable jTableResultado;
    private javax.swing.JTextField jTextFieldDescricao;
    private javax.swing.JTextField jTextFieldIdMovimentacao;
    // End of variables declaration//GEN-END:variables
}
