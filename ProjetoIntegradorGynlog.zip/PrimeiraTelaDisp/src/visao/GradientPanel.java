package visao;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;


public class GradientPanel extends JPanel {
    private Color color1 = new Color(15, 188, 179); // azul claro
    private Color color2 = new Color(0, 111, 122);  // azul escuro

    public GradientPanel() {
        setOpaque(true);
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        GradientPaint gp = new GradientPaint(
                0, 0, color1,
                0, getHeight(), color2
        );
        g2d.setPaint(gp);
        g2d.fillRect(0, 0, getWidth(), getHeight());
        g2d.dispose();
    }
}
