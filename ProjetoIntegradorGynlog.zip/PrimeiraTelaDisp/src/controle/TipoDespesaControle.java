package controle;

import java.util.ArrayList;
import modelos.classes.TipoDeDespesa;
import modelos.interfaces.ITipoDeDespesasCRUD;
import persistencia.TipoDeDespesasDAO;

public class TipoDespesaControle implements ITipoDeDespesasCRUD {

    private TipoDeDespesasDAO dao;

    public TipoDespesaControle() {
        dao = new TipoDeDespesasDAO();
    }
    @Override
    public void salvar(TipoDeDespesa tipo) throws Exception {
        // validações
        
        if(tipo.getIdTipoDeDespesa() <= 0)throw new Exception("O ID não pode ser menor que zero.");
           
        TipoDeDespesa existente = dao.buscarPorId(tipo.getIdTipoDeDespesa()); // verificar se o ID já existe
        if (existente != null) throw new Exception("Esse ID já existe! Escolha outro.");
        
        dao.salvar(tipo); // Se passou, chama o DAO
    }

    @Override
    public ArrayList<TipoDeDespesa> listaDeTiposDeDespesas() throws Exception {
        return dao.listaDeTiposDeDespesas();
    }
    @Override
    public TipoDeDespesa buscarPorId(int id) throws Exception {
        return dao.buscarPorId(id);
    }
    @Override
    public void atualizar(TipoDeDespesa tipo) throws Exception {

         if(tipo.getIdTipoDeDespesa() <= 0)throw new Exception("O ID não pode ser menor que zero.");
        // verificar se existe no banco
        TipoDeDespesa original = dao.buscarPorId(tipo.getIdTipoDeDespesa());
        if (original == null)
            throw new Exception("Essa despesa não existe mais no banco!");

        // verifica se o usuário tentou mudar o ID
        // (O ID vem da tabela, não do campo de texto)
        // Então a tela deve enviar o ID ORIGINAL da linha selecionada
        if (tipo.getIdTipoDeDespesa() != original.getIdTipoDeDespesa())
            throw new Exception("Não é permitido alterar o ID!");
        // Se passou, atualizar
        dao.atualizar(tipo);
    }

    @Override
    public void remover(int id) throws Exception {
        TipoDeDespesa tipo = dao.buscarPorId(id);
        dao.remover(id);
    }
}