
package modelos.interfaces;
import java.util.ArrayList;
import modelos.classes.TipoDeMovimentacao;

public interface ITipoDeMovimentacaoCRUD {

  void salvar(TipoDeMovimentacao tipoDeMovimentacao) throws Exception;
  ArrayList<TipoDeMovimentacao> listaDeTiposDeMovimentacao() throws Exception;
  TipoDeMovimentacao buscarPorId(int idMovimentacao) throws Exception;
  void atualizar(TipoDeMovimentacao tipoDeMovimentacao) throws Exception;
  void remover(int idMovimentacao) throws Exception;
}