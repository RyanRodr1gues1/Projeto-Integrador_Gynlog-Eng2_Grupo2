
package persistencia;
import java.util.ArrayList;
import modelos.classes.TipoDeMovimentacao;
import modelos.interfaces.ITipoDeMovimentacaoCRUD;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import modelos.classes.TipoDeDespesa;

public class TipoDeMovimentacaoDAO implements ITipoDeMovimentacaoCRUD {
  private String nomeDoArquivoNoDisco = null;

  public TipoDeMovimentacaoDAO(){
    nomeDoArquivoNoDisco = "./src/bancodedados/Movimentacao.txt";
  }
      @Override
  public void salvar(TipoDeMovimentacao tipoDeMovimentacao) throws Exception {
    try{
      //cria o arquivo
      FileWriter fw = new FileWriter(nomeDoArquivoNoDisco,true);
      //Criar o buffer do arquivo
      BufferedWriter bw = new BufferedWriter(fw);
      //Escreve no arquivo
      String str = tipoDeMovimentacao.getIdMovimentacao() + ";";
      str += tipoDeMovimentacao.getIdVeiculo() + ";";
      str += tipoDeMovimentacao.getIdTipoDespesa() + ";";
      str += tipoDeMovimentacao.getDescricao() + ";";
      str += tipoDeMovimentacao.getData() + ";";
      str += tipoDeMovimentacao.getValor() + "\n";
      bw.write(str);
      //fecha o arquivo
      bw.close();		
    }catch(Exception erro){
      String msg = "Persistencia - Metodo Salvar - "+erro.getMessage();
      throw new Exception(msg);
    }
  }

  @Override
  public ArrayList<TipoDeMovimentacao> listaDeTiposDeMovimentacao() throws Exception {
    try{
      ArrayList<TipoDeMovimentacao> listaDeTiposDeMovimentacao = new ArrayList<>();
      //abrir um arquivo existente
      FileReader fr = new FileReader(nomeDoArquivoNoDisco);
      //Criar o buffer do arquivo
      BufferedReader br  = new BufferedReader(fr);
      String linha = "";
      while((linha=br.readLine())!= null){
         if (linha.trim().isEmpty()) continue;
        String vetorStr[] = linha.split(";");
        if (vetorStr.length < 6) continue;
        
        int idTipoDeMovimentacaoAux = Integer.parseInt(vetorStr[0]);
        String idVeiculoAux = vetorStr[1];
        String idTipoDespesaAux= vetorStr[2];
        String descricao = vetorStr[3];
        String data = vetorStr[4];
        double valor = Double.parseDouble(vetorStr[5]);
        TipoDeMovimentacao obj = new TipoDeMovimentacao(idTipoDeMovimentacaoAux, idVeiculoAux, idTipoDespesaAux, descricao, data, valor);
        listaDeTiposDeMovimentacao.add(obj);
      }
      br.close();
      return listaDeTiposDeMovimentacao;

    }catch(Exception erro){
      String msg = "Persistencia - Metodo Lista - "+erro.getMessage();
      throw new Exception(msg);
    }  
  }

  @Override
  public TipoDeMovimentacao buscarPorId(int idMovimentacao) throws Exception {
    try{
      FileReader fr = new FileReader(nomeDoArquivoNoDisco);
      BufferedReader br  = new BufferedReader(fr);
      String linha = "";

      while((linha=br.readLine())!=null){
        String vetorStr[] = linha.split(";");
        int idAux = Integer.parseInt(vetorStr[0]);
        if(linha.trim().isEmpty()) continue; // IGNORA LINHA VAZIA
        if(vetorStr.length < 6) continue; // IGNORA LINHA INVÁLIDA
        // IGNORA LINHAS COM ID VAZIO
        if (vetorStr[0].trim().isEmpty()) continue;

        if(idAux == idMovimentacao){
        String idVeiculo = vetorStr[1];
        String idTipoDespesa= vetorStr[2];
        String descricao = vetorStr[3];
        String data = vetorStr[4];
        double valor = Double.parseDouble(vetorStr[5]);
        TipoDeMovimentacao obj = null;
          obj = new TipoDeMovimentacao(idAux,idVeiculo,idTipoDespesa,descricao,data,valor);
          br.close();
          return obj;
        }
      }

      br.close();
      return null;

    }catch(Exception erro){
      String msg = "Persistencia - Metodo Buscar - "+erro.getMessage();
      throw new Exception(msg);
    }   
  }

  @Override
  public void atualizar(TipoDeMovimentacao tipoDeMovimentacao) throws Exception {
    try {
      ArrayList<TipoDeMovimentacao> listagem = this.listaDeTiposDeMovimentacao();

      FileWriter fw = new FileWriter(nomeDoArquivoNoDisco);
      BufferedWriter bw = new BufferedWriter(fw);

      for(TipoDeMovimentacao obj : listagem){
        if(obj.getIdMovimentacao() == tipoDeMovimentacao.getIdMovimentacao()){
          String str = tipoDeMovimentacao.getIdMovimentacao() + ";";
          str += tipoDeMovimentacao.getIdVeiculo() + ";";
          str += tipoDeMovimentacao.getIdTipoDespesa() + ";";
          str += tipoDeMovimentacao.getDescricao() + ";";
          str += tipoDeMovimentacao.getData() + ";";
          str += tipoDeMovimentacao.getValor() + "\n";
          bw.write(str);
        }else{
          String str = obj.getIdMovimentacao() + ";";
          str += obj.getIdVeiculo() + ";";
          str += obj.getIdTipoDespesa() + ";";
          str += obj.getDescricao() + ";";
          str += obj.getData() + ";";
          str += obj.getValor() + "\n";
          bw.write(str);
        }
      }

      bw.close();
    }catch(Exception erro){
      String msg = "Persistencia - Metodo Atualizar - "+erro.getMessage();
      throw new Exception(msg);
    } 
  }

  @Override
  public void remover(int idMovimentacao) throws Exception {
    try {
      ArrayList<TipoDeMovimentacao> listagem = this.listaDeTiposDeMovimentacao();

      FileWriter fw = new FileWriter(nomeDoArquivoNoDisco);
      BufferedWriter bw = new BufferedWriter(fw);

      for(TipoDeMovimentacao obj : listagem){
        if(obj.getIdMovimentacao() != idMovimentacao){
          String str = obj.getIdMovimentacao() + ";";
          str += obj.getIdVeiculo() + ";";
          str += obj.getIdTipoDespesa() + ";";
          str += obj.getDescricao() + ";";
          str += obj.getData() + ";";
          str += obj.getValor() + "\n";
          bw.write(str);
        }
      }

      bw.close();
    }catch(Exception erro){
      String msg = "Persistencia - Metodo Remover - "+erro.getMessage();
      throw new Exception(msg);
    } 
  }
}


 

 