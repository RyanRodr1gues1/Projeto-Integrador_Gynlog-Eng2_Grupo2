
package visao;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelos.classes.*;
import persistencia.VeiculosDAO;
import controle.*;
import java.awt.Color;

public class TelaCadrastroVeiculos extends javax.swing.JFrame {

    public TelaCadrastroVeiculos() throws Exception {
        initComponents();
        carregarTabela();
        setLocationRelativeTo(null);
        controle = new VeiculoControle();
        jTextFieldID.setEditable(true);
    }
    Veiculos obj = null;
    VeiculoControle controle = null;
    

    private void carregarTabela() {
        try {
            VeiculosDAO dao = new VeiculosDAO();
            ArrayList<Veiculos> lista = dao.listaDeVeiculos();

            DefaultTableModel modelo = (DefaultTableModel) jTableSaida.getModel();
            modelo.setRowCount(0);

            for (Veiculos obj : lista) {
                modelo.addRow(new Object[]{obj.getIdVeiculo(), obj.getPlaca(), obj.getModelo(),
                    obj.getAnoFabricacao(), obj.getStatus()});
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar tabela: " + e.getMessage());
        }
    }

    private void limparCampos() {
        jTextFieldID.setText("");
        jTextFieldPlaca.setText("");
        jTextFieldModelo.setText("");
        jTextFieldAnoFabricacao.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new GradientPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new RoundedPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextFieldID = new javax.swing.JTextField();
        jTextFieldPlaca = new javax.swing.JTextField();
        jTextFieldModelo = new javax.swing.JTextField();
        jTextFieldAnoFabricacao = new javax.swing.JTextField();
        jComboBoxStatus = new javax.swing.JComboBox<>();
        jButtonIncluir = new javax.swing.JButton();
        jButtonEditar = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableSaida = new javax.swing.JTable();
        jButtonVoltar = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/carr.png"))); // NOI18N
        jLabel1.setText("Cadrastro de Veiculos");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setForeground(new java.awt.Color(255, 204, 255));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("ID VEÍCULO:");

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("PLACA:");

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("MODELO:");

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("ANO DE FABRICAÇÃO:");

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("REGISTRO DE VEÍCULO:");

        jTextFieldID.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldID.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextFieldID.setForeground(new java.awt.Color(0, 0, 0));
        jTextFieldID.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 3));

        jTextFieldPlaca.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldPlaca.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextFieldPlaca.setForeground(new java.awt.Color(0, 0, 0));
        jTextFieldPlaca.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 3));

        jTextFieldModelo.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldModelo.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextFieldModelo.setForeground(new java.awt.Color(0, 0, 0));
        jTextFieldModelo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 3));

        jTextFieldAnoFabricacao.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldAnoFabricacao.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextFieldAnoFabricacao.setForeground(new java.awt.Color(0, 0, 0));
        jTextFieldAnoFabricacao.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 3));

        jComboBoxStatus.setBackground(new java.awt.Color(255, 255, 255));
        jComboBoxStatus.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jComboBoxStatus.setForeground(new java.awt.Color(0, 0, 0));
        jComboBoxStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ativo", "Inativo" }));
        jComboBoxStatus.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 3));

        jButtonIncluir.setBackground(new java.awt.Color(0, 102, 102));
        jButtonIncluir.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButtonIncluir.setForeground(new java.awt.Color(255, 255, 255));
        jButtonIncluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/incluir.png"))); // NOI18N
        jButtonIncluir.setText("INCLUIR");
        jButtonIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonIncluirActionPerformed(evt);
            }
        });

        jButtonEditar.setBackground(new java.awt.Color(0, 102, 102));
        jButtonEditar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButtonEditar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/ediatrCerto.png"))); // NOI18N
        jButtonEditar.setText("EDITAR");
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });

        jButtonExcluir.setBackground(new java.awt.Color(0, 102, 102));
        jButtonExcluir.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButtonExcluir.setForeground(new java.awt.Color(255, 255, 255));
        jButtonExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/li.png"))); // NOI18N
        jButtonExcluir.setText("EXCLUIR");
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel6)
                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING))
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addGap(37, 37, 37)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextFieldID, javax.swing.GroupLayout.DEFAULT_SIZE, 172, Short.MAX_VALUE)
                    .addComponent(jTextFieldPlaca)
                    .addComponent(jTextFieldModelo)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jComboBoxStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jTextFieldAnoFabricacao))
                .addGap(49, 49, 49)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonIncluir)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jButtonExcluir, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonEditar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jTextFieldID, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(jLabel3))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(jTextFieldPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jButtonIncluir, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jButtonEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4)
                                .addGap(70, 70, 70)))
                        .addComponent(jLabel6)
                        .addContainerGap())
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jTextFieldModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel5)
                                .addComponent(jTextFieldAnoFabricacao, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBoxStatus, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE))))
        );

        jTableSaida.setBackground(new java.awt.Color(255, 255, 255));
        jTableSaida.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID Veiculo", "Placa", "Modelo", "Ano Fabricação", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableSaida.setGridColor(new java.awt.Color(0, 0, 0));
        jTableSaida.setSelectionBackground(new java.awt.Color(0, 204, 204));
        jTableSaida.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableSaidaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTableSaida);

        jButtonVoltar.setBackground(new java.awt.Color(0, 102, 102));
        jButtonVoltar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButtonVoltar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonVoltar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/voltarll.png"))); // NOI18N
        jButtonVoltar.setText("VOLTAR");
        jButtonVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonVoltarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(216, 216, 216))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jButtonVoltar)
                                .addContainerGap())))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 113, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonIncluirActionPerformed
        // TODO add your handling code here:      
        try {
            String idEx = jTextFieldID.getText().trim();
            String modeloEx = jTextFieldModelo.getText().trim();
            String placaEx = jTextFieldPlaca.getText().trim();
            String anoEx = jTextFieldAnoFabricacao.getText().trim();
            
            if( idEx.isEmpty()) throw new Exception("O ID não pode estar vazio");
            if( modeloEx.isEmpty()) throw new Exception("O modelo não pode estar vazio");
            if( placaEx.isEmpty()) throw new Exception("A placa não pode estar vazia");
            if( anoEx.isEmpty()) throw new Exception("O ano não pode estar vazio");
            
            jTextFieldID.setEditable(true);
            int idNovo = Integer.parseInt(jTextFieldID.getText());
            String placa = jTextFieldPlaca.getText();
            String modelo = jTextFieldModelo.getText();
            int anoFabricacao = Integer.parseInt(jTextFieldAnoFabricacao.getText());
            StatusVeiculo status = (StatusVeiculo.valueOf(jComboBoxStatus.getSelectedItem().toString()));

            Veiculos v = new Veiculos(idNovo, placa, modelo, anoFabricacao, status);

            controle.salvar(v);
            JOptionPane.showMessageDialog(null, "Veículo incluído!");
            carregarTabela();
            limparCampos();

        } catch (Exception erro) {
            JOptionPane.showMessageDialog(this, "Erro ao Incluir: " +erro.getMessage());
        }
    }//GEN-LAST:event_jButtonIncluirActionPerformed

    private void jButtonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditarActionPerformed
        // TODO add your handling code here:
        try {
            String idEx = jTextFieldID.getText().trim();
            String modeloEx = jTextFieldModelo.getText().trim();
            String placaEx = jTextFieldPlaca.getText().trim();
            String anoEx = jTextFieldAnoFabricacao.getText().trim();
            
            if( idEx.isEmpty()) throw new Exception("O ID não pode estar vazio");
            if( modeloEx.isEmpty()) throw new Exception("O modelo não pode estar vazio");
            if( placaEx.isEmpty()) throw new Exception("A placa não pode estar vazia");
            if( anoEx.isEmpty()) throw new Exception("O ano não pode estar vazio");
            
            int linha = jTableSaida.getSelectedRow();
            
            if (linha == -1) {
                JOptionPane.showMessageDialog(this, "Selecione uma despesa para editar!");
                return;
            }
            int id = Integer.parseInt(jTableSaida.getValueAt(linha, 0).toString());
            String placa = jTextFieldPlaca.getText();
            String modelo = jTextFieldModelo.getText();
            int anoFabricacao = Integer.parseInt(jTextFieldAnoFabricacao.getText());
            StatusVeiculo status = StatusVeiculo.valueOf(jComboBoxStatus.getSelectedItem().toString());

            Veiculos obj = new Veiculos(id, placa, modelo, anoFabricacao, status);
            controle.atualizar(obj);
            JOptionPane.showMessageDialog(this, "Cadastro atualizad!");
            jTextFieldID.setEditable(true);
            jTextFieldID.setText("");
            jTextFieldID.setBackground(new Color(255,255,255));
            jTextFieldID.setForeground(Color.BLACK);
            limparCampos();
            carregarTabela();
        } catch (Exception erro) {
            JOptionPane.showMessageDialog(this, "Erro ao Editar: " +erro.getMessage());
            
        }
    }//GEN-LAST:event_jButtonEditarActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
        // TODO add your handling code here:
        try { 
            int linha = jTableSaida.getSelectedRow();
            if (linha == -1) {
                JOptionPane.showMessageDialog(this, "Selecione uma linha para remover!");
                return;
            }
            int id = Integer.parseInt(jTableSaida.getValueAt(linha, 0).toString());
            controle.remover(id);
            JOptionPane.showMessageDialog(this, "Veiculo removido com sucesso!");
            carregarTabela();
            jTextFieldID.setEditable(true);
            jTextFieldID.setText("");
            jTextFieldID.setBackground(new Color(255,255,255));
            jTextFieldID.setForeground(Color.BLACK);
            limparCampos();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao remover: " + e.getMessage());
        }
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jButtonVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonVoltarActionPerformed
        // TODO add your handling code here:
        JanelaPrincipal Janela = new JanelaPrincipal();
        Janela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButtonVoltarActionPerformed

    private void jTableSaidaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableSaidaMouseClicked
        // TODO add your handling code here:
        int linha = jTableSaida.getSelectedRow();
        if (linha >= 0) {
            jTextFieldID.setText(jTableSaida.getValueAt(linha, 0).toString());
            jTextFieldPlaca.setText(jTableSaida.getValueAt(linha, 1).toString());
            jTextFieldModelo.setText(jTableSaida.getValueAt(linha, 2).toString());
            jTextFieldAnoFabricacao.setText(jTableSaida.getValueAt(linha, 3).toString());
            jComboBoxStatus.setSelectedItem(jTableSaida.getValueAt(linha, 4).toString());

            jTextFieldID.setEditable(false);
            jTextFieldID.setBackground(Color.LIGHT_GRAY);
            jTextFieldID.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_jTableSaidaMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new TelaCadrastroVeiculos().setVisible(true);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonEditar;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonIncluir;
    private javax.swing.JButton jButtonVoltar;
    private javax.swing.JComboBox<String> jComboBoxStatus;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTableSaida;
    private javax.swing.JTextField jTextFieldAnoFabricacao;
    private javax.swing.JTextField jTextFieldID;
    private javax.swing.JTextField jTextFieldModelo;
    private javax.swing.JTextField jTextFieldPlaca;
    // End of variables declaration//GEN-END:variables

}
