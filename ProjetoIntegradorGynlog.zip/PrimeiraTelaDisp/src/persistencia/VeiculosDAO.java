
package persistencia;

import java.io.BufferedReader;
import modelos.classes.Veiculos;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import modelos.classes.StatusVeiculo;
import modelos.interfaces.IVeiculosCRUD;

public class VeiculosDAO implements IVeiculosCRUD {

    private String nomeDoArquivoNoDisco = null;

    public VeiculosDAO() {
        nomeDoArquivoNoDisco = "./src/bancodedados/Veiculos.txt";
    }

    public boolean idExiste(ArrayList<Veiculos> lista, int idNovo) {
        for (Veiculos v : lista) {
            if (v.getIdVeiculo() == idNovo) {
                return true; // achou ID repetido
            }
        }
        return false; // ID não existe
    }

    @Override
    public Veiculos buscarPorId(int idVeiculo) throws Exception {
        try {
            //abrir um arquivo existente
            FileReader fr = new FileReader(nomeDoArquivoNoDisco);
            //Criar o buffer do arquivo
            BufferedReader br = new BufferedReader(fr);
            String linha = "";

            while ((linha = br.readLine()) != null) {

                String vetorStr[] = linha.split(";");

                int idVeiculoAux = Integer.parseInt(vetorStr[0]);
                if (idVeiculoAux == idVeiculo) {

                    String placa = vetorStr[1];
                    String modelo = vetorStr[2];
                    int anoFabricacao = Integer.parseInt(vetorStr[3]);
                    StatusVeiculo status = StatusVeiculo.valueOf(vetorStr[4]);

                    Veiculos objVeiculo = null;

                    objVeiculo = new Veiculos(idVeiculo, placa, modelo, anoFabricacao, status);
                    br.close();
                    return objVeiculo;
                }
            }
            br.close();
            return null;
        } catch (Exception erro) {
            String msg = "O ID já existe, digite outro ";
            throw new Exception(msg);
        }
    }

    @Override
    public void salvar(Veiculos veiculo) throws Exception {
        FileWriter fw = new FileWriter(nomeDoArquivoNoDisco, true);
        BufferedWriter bw = new BufferedWriter(fw);

        String str = veiculo.getIdVeiculo() + ";"
                + veiculo.getPlaca() + ";"
                + veiculo.getModelo() + ";"
                + veiculo.getAnoFabricacao() + ";"
                + veiculo.getStatus().name() + "\n";

        bw.write(str);
        bw.close();

    }

    @Override
    public ArrayList<Veiculos> listaDeVeiculos() throws Exception {

        try {
            ArrayList<Veiculos> lista = new ArrayList<>();

            FileReader fr = new FileReader(nomeDoArquivoNoDisco);
            BufferedReader br = new BufferedReader(fr);
            String linha = "";

            while ((linha = br.readLine()) != null) {

                if (linha.trim().isEmpty()) {
                    continue;
                }

                String vetorStr[] = linha.split(";");

                // Garantir formato correto
                if (vetorStr.length < 5) {
                    continue;
                }

                int idVeiculo = Integer.parseInt(vetorStr[0]);
                String placa = vetorStr[1];
                String modelo = vetorStr[2];
                int anoFabricacao = Integer.parseInt(vetorStr[3]);
                StatusVeiculo status = StatusVeiculo.valueOf(vetorStr[4]);

                // AGORA SIM: cria o objeto COMPLETO
                Veiculos veic = new Veiculos(idVeiculo, placa, modelo, anoFabricacao, status);

                lista.add(veic);
            }

            br.close();
            return lista;

        } catch (Exception e) {
            throw new Exception("Erro ao ler lista de veículos!");
        }
    }

    @Override
    public void atualizar(Veiculos veiculo) throws Exception {
        try {
            ArrayList<Veiculos> listagem = this.listaDeVeiculos();

            try (FileWriter fw = new FileWriter(nomeDoArquivoNoDisco); BufferedWriter bw = new BufferedWriter(fw)) {

                for (Veiculos obj : listagem) {
                    if (obj.getIdVeiculo() != veiculo.getIdVeiculo()) {
                        String str = obj.getIdVeiculo() + ";"
                                + obj.getPlaca() + ";"
                                + obj.getModelo() + ";"
                                + obj.getAnoFabricacao() + ";"
                                + obj.getStatus().name() + "\n";
                        bw.write(str);
                    } else {
                        String str = veiculo.getIdVeiculo() + ";"
                                + veiculo.getPlaca() + ";"
                                + veiculo.getModelo() + ";"
                                + veiculo.getAnoFabricacao() + ";"
                                + veiculo.getStatus().name() + "\n";
                        bw.write(str);
                    }
                }
            }
        } catch (Exception erro) {
            throw new Exception("Erro ao atualizar: ");
        }
    }

    @Override
    public void remover(int idVeiculo) throws Exception {
        try {
            ArrayList<Veiculos> listagem = this.listaDeVeiculos();

            try (FileWriter fw = new FileWriter(nomeDoArquivoNoDisco); BufferedWriter bw = new BufferedWriter(fw)) {

                for (Veiculos obj : listagem) {
                    if (obj.getIdVeiculo() != idVeiculo) {
                        String str = obj.getIdVeiculo() + ";"
                                + obj.getPlaca() + ";"
                                + obj.getModelo() + ";"
                                + obj.getAnoFabricacao() + ";"
                                + obj.getStatus().name() + "\n";
                        bw.write(str);
                    }
                }
            }
        } catch (Exception erro) {
            throw new Exception("Não foi possível remover: ");
        }
    }

    @Override
    public Veiculos buscarPorPlaca(String placaProcurada) throws Exception {
        try {
            FileReader fr = new FileReader(nomeDoArquivoNoDisco);
            BufferedReader br = new BufferedReader(fr);
            String linha = "";

            while ((linha = br.readLine()) != null) {

                if (linha.trim().isEmpty()) {
                    continue;
                }

                String vetorStr[] = linha.split(";");
                if (vetorStr.length < 5) {
                    continue;
                }

                String placaLida = vetorStr[1];

                if (placaLida.equalsIgnoreCase(placaProcurada)) {
                    int idVeiculo = Integer.parseInt(vetorStr[0]);
                    String modelo = vetorStr[2];
                    int anoFabricacao = Integer.parseInt(vetorStr[3]);
                    StatusVeiculo status = StatusVeiculo.valueOf(vetorStr[4]);

                    br.close();
                    return new Veiculos(idVeiculo, placaLida, modelo, anoFabricacao, status);
                }
            }

            br.close();
            return null;

        } catch (Exception e) {
            throw new Exception("Erro ao buscar placa!");
        }
    }
}
