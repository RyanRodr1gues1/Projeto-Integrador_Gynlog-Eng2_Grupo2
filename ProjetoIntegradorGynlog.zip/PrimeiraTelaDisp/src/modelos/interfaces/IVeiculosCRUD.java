
package modelos.interfaces;
import java.util.ArrayList;
import modelos.classes.Veiculos;

public interface IVeiculosCRUD {
    
    void salvar(Veiculos veiculo) throws Exception;
    ArrayList<Veiculos> listaDeVeiculos() throws Exception;
    Veiculos buscarPorPlaca(String placaProcurada)throws Exception;
    Veiculos buscarPorId(int idVeiculo) throws Exception;
    void atualizar(Veiculos veiculo) throws Exception;
    void remover(int idVeiculo) throws Exception;
}
