
package modelos.classes;

public class TipoDeMovimentacao {

    // Atributos 
    private int idMovimentacao = 0;
    private String idVeiculo = "";
    private String idTipoDespesa = "";
    private String descricao = "";
    private String data = "";
    private double valor = 0.0;

    //Metodos
    public TipoDeMovimentacao() {
    }

    public TipoDeMovimentacao(int idMovimentacao, String idVeiculo, String idTipoDespesa, String descricao, String data, double valor) {
        this.idMovimentacao = idMovimentacao;
        this.idVeiculo = idVeiculo;
        this.idTipoDespesa = idTipoDespesa;
        this.descricao = descricao;
        this.data = data;
        this.valor = valor;
    }

    public int getIdMovimentacao() {
        return idMovimentacao;
    }

    public void setIdMovimentacao(int idMovimentacao) {
        this.idMovimentacao = idMovimentacao;
    }

    public String getIdVeiculo() {
        return idVeiculo;
    }

    public void setIdVeiculo(String idVeiculo) {
        this.idVeiculo = idVeiculo;
    }

    public String getIdTipoDespesa() {
        return idTipoDespesa;
    }

    public void setIdTipoDespesa(String idTipoDespesa) {
        this.idTipoDespesa = idTipoDespesa;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}
